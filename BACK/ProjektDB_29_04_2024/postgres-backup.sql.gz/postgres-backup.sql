--
-- PostgreSQL database dump
--

-- Dumped from database version 13.14 (Debian 13.14-1.pgdg110+2)
-- Dumped by pg_dump version 13.14 (Debian 13.14-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Aufgaben; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Aufgaben" (
    "ID" integer NOT NULL,
    "Aufgabenname" character varying(255) NOT NULL,
    "Beschreibung" character varying(500),
    "Startdatum" date,
    "Enddatum" date,
    "Status" character varying(50),
    "ProjektID" integer,
    "MitarbeiterID" integer
);


ALTER TABLE public."Aufgaben" OWNER TO postgres;

--
-- Name: Aufgaben_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Aufgaben" ALTER COLUMN "ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Aufgaben_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: Mitarbeiter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Mitarbeiter" (
    "ID" integer NOT NULL,
    "Vorname" character varying(50),
    "Nachname" character varying(50),
    "Abteilung" character varying(100)
);


ALTER TABLE public."Mitarbeiter" OWNER TO postgres;

--
-- Name: Mitarbeiter_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Mitarbeiter" ALTER COLUMN "ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Mitarbeiter_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: Projekte; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Projekte" (
    "ID" integer NOT NULL,
    "Projektname" character varying(255) NOT NULL,
    "Startdatum" date,
    "Enddatum" date,
    "Budget" numeric
);


ALTER TABLE public."Projekte" OWNER TO postgres;

--
-- Name: Projekte_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Projekte" ALTER COLUMN "ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Projekte_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Data for Name: Aufgaben; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Aufgaben" ("ID", "Aufgabenname", "Beschreibung", "Startdatum", "Enddatum", "Status", "ProjektID", "MitarbeiterID") FROM stdin;
1	Website Redesign	Überarbeitung der Unternehmenswebsite für ein moderneres Design	2023-05-07	2023-12-12	ZURÜCKGEGEBEN	1	1
2	Kundenbefragung	Durchführung einer Umfrage zur Kundenzufriedenheit und Analyse der Ergebnisse	2023-06-17	2023-12-20	Abgeschlossen	2	1
3	Produktentwicklung	Entwicklung eines neuen Produkts basierend auf den Kundenanforderungen	2023-12-28	2024-05-03	IN BEARBEITUNG	3	1
4	Marketingkampagne	 Planung und Durchführung einer Marketingkampagne zur Steigerung der Markenbekanntheit	2024-01-05	2024-03-14	UNVOLLSTÄNDIG	4	2
5	Schulungsprogramm	Organisation von Schulungen für neue Mitarbeiter zur Einarbeitung in Unternehmensprozesse	2023-12-28	2024-12-12	IN BEARBEITUNG	5	3
6	Qualitätssicherung	Überprüfung der Produktqualität und Implementierung von Verbesserungsmaßnahmen	2024-01-09	2025-12-12	IN BEARBEITUNG	4	3
7	Eventplanung	Planung und Organisation eines Unternehmensevents zur Kundenbindung	2024-01-22	2024-12-28	IN BEARBEITUNG	5	1
8	Budgetüberprüfung	Überprüfung des Budgets für das laufende Quartal und Anpassung der Ausgaben	2024-01-30	2025-01-06	IN BEARBEITUNG	2	2
9	Marktforschung	Durchführung einer Marktanalyse zur Identifizierung neuer Geschäftsmöglichkeiten	2023-12-28	2024-01-06	Abgeschlossen	5	3
10	Mitarbeiterbewertung	Durchführung von Leistungsbewertungen für Mitarbeiter und Festlegung von Entwicklungszielen	2024-05-01	2025-06-12	Geplant	3	2
\.


--
-- Data for Name: Mitarbeiter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Mitarbeiter" ("ID", "Vorname", "Nachname", "Abteilung") FROM stdin;
1	Robin	Schmidt	abt.01
2	Lorie	Fischer	abt.02
3	Roger	Meyer	abt.03
\.


--
-- Data for Name: Projekte; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Projekte" ("ID", "Projektname", "Startdatum", "Enddatum", "Budget") FROM stdin;
1	Website Redesign	2023-01-23	2023-06-14	30000
2	Product Launch	2023-01-29	2023-07-15	45000
3	Marketing Campaign	2023-02-02	2023-07-14	52000
4	Software Development	2023-03-11	2023-05-10	18000
5	Training Program	2023-04-23	2023-10-21	69999
\.


--
-- Name: Aufgaben_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Aufgaben_ID_seq"', 10, true);


--
-- Name: Mitarbeiter_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Mitarbeiter_ID_seq"', 3, true);


--
-- Name: Projekte_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Projekte_ID_seq"', 5, true);


--
-- Name: Aufgaben Aufgaben_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Aufgaben"
    ADD CONSTRAINT "Aufgaben_pkey" PRIMARY KEY ("ID");


--
-- Name: Mitarbeiter Mitarbeiter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Mitarbeiter"
    ADD CONSTRAINT "Mitarbeiter_pkey" PRIMARY KEY ("ID");


--
-- Name: Projekte Projekte_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Projekte"
    ADD CONSTRAINT "Projekte_pkey" PRIMARY KEY ("ID");


--
-- Name: fki_FK_Aufgabe-MitarbeiterID_Mitarbeiter-ID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "fki_FK_Aufgabe-MitarbeiterID_Mitarbeiter-ID" ON public."Aufgaben" USING btree ("MitarbeiterID");


--
-- Name: fki_FK_Aufgabe-ProjektID_Projekte-ID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "fki_FK_Aufgabe-ProjektID_Projekte-ID" ON public."Aufgaben" USING btree ("ProjektID");


--
-- Name: Aufgaben FK_Aufgabe-MitarbeiterID_Mitarbeiter-ID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Aufgaben"
    ADD CONSTRAINT "FK_Aufgabe-MitarbeiterID_Mitarbeiter-ID" FOREIGN KEY ("MitarbeiterID") REFERENCES public."Mitarbeiter"("ID") NOT VALID;


--
-- Name: Aufgaben FK_Aufgabe-ProjektID_Projekte-ID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Aufgaben"
    ADD CONSTRAINT "FK_Aufgabe-ProjektID_Projekte-ID" FOREIGN KEY ("ProjektID") REFERENCES public."Projekte"("ID") NOT VALID;


--
-- PostgreSQL database dump complete
--

